const back2Top = document.querySelector('#back2Top');



back2Top.addEventListener('click', (e) => {
    e.preventDefault();
    window.scroll({top:0, left:0, behavior: 'smooth'});
});
